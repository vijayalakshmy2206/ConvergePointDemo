$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("file:src/test/resources/Features/AddToCartValidation.feature");
formatter.feature({
  "name": "Convergepoint demo for Amazon.com",
  "description": "",
  "keyword": "Feature"
});
formatter.scenario({
  "name": "Add to cart validation",
  "description": "",
  "keyword": "Scenario"
});
formatter.before({
  "status": "passed"
});
formatter.step({
  "name": "Navigate to Amazon.in homepage.",
  "keyword": "Given "
});
formatter.match({
  "location": "com.stepdefinitions.HomePageTest.navigate_to_Amazon_in_homepage()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "Click on Fashion and Click on Mens",
  "keyword": "When "
});
formatter.match({
  "location": "com.stepdefinitions.HomePageTest.click_on_Fashion_and_Click_on_Mens()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "Filter by Average customer review of 4 stars and Up",
  "keyword": "And "
});
formatter.match({
  "location": "com.stepdefinitions.HomePageTest.filter_by_Average_customer_review_of_stars_and_Up(java.lang.Integer)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "Filter by price",
  "keyword": "And "
});
formatter.match({
  "location": "com.stepdefinitions.HomePageTest.filter_by_price()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "Select Puma and Allen Solly in Brands",
  "keyword": "And "
});
formatter.match({
  "location": "com.stepdefinitions.HomePageTest.select_Puma_and_Allen_Solly_in_Brands()"
});
formatter.result({
  "error_message": "java.lang.AssertionError\r\n\tat org.junit.Assert.fail(Assert.java:86)\r\n\tat org.junit.Assert.assertTrue(Assert.java:41)\r\n\tat org.junit.Assert.assertTrue(Assert.java:52)\r\n\tat com.stepdefinitions.HomePageTest.select_Puma_and_Allen_Solly_in_Brands(HomePageTest.java:56)\r\n\tat ✽.Select Puma and Allen Solly in Brands(file:///C:/Users/Admin/Downloads/MavenProject/MavenProject/src/test/resources/Features/AddToCartValidation.feature:8)\r\n",
  "status": "failed"
});
formatter.step({
  "name": "Count the number of results in the first page and log it to console.",
  "keyword": "And "
});
formatter.match({
  "location": "com.stepdefinitions.HomePageTest.count_the_number_of_results_in_the_first_page_and_log_it_to_console()"
});
formatter.result({
  "status": "skipped"
});
formatter.step({
  "name": "Click second product and add it to Cart.",
  "keyword": "And "
});
formatter.match({
  "location": "com.stepdefinitions.HomePageTest.click_second_product_and_add_it_to_Cart()"
});
formatter.result({
  "status": "skipped"
});
formatter.step({
  "name": "Validate Number on the Cart is increased by one",
  "keyword": "Then "
});
formatter.match({
  "location": "com.stepdefinitions.HomePageTest.validate_Number_on_the_Cart_is_increased_by_one()"
});
formatter.result({
  "status": "skipped"
});
formatter.after({
  "status": "passed"
});
formatter.after({
  "status": "passed"
});
});