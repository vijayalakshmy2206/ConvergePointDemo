package org.pageobject;

import java.util.List;

import org.base.BaseClass;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class HomePage extends BaseClass{

	public HomePage() {
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(xpath="//a[@aria-label='Open Menu']")	
	private WebElement allMenu; 
	@FindBy(xpath="//div[contains(text(),'Men') and contains(text(), 'Fashion')]/parent::a")	
	private WebElement mensFashionMenu; 
	@FindBy(xpath="//span[text()='4 Stars & Up']")	
	private WebElement starFilter;
	@FindBy(xpath="//span[text()='₹1,000 - ₹1,500']/parent::a")	
	private WebElement priceFilter;
	@FindBy(xpath="//span[text()='Puma']/preceding-sibling::div/label/child::input")	
	private WebElement pumaFilter;
	@FindBy(xpath="//span[text()='Solly']/preceding-sibling::div/label/child::input")	
	private WebElement allenSolyFilter;
	@FindBy(xpath="//h2[contains(@class,'a-size-mini a-spacing-none a-color-base s-line-clamp-2')]/child::a")	
	private List<WebElement> listOfItemsInFirstPage;
	@FindBy(xpath="//input[@value='Add to Cart']")	
	private WebElement addToCartButton;
	@FindBy(xpath="//div[@id='nav-cart-count-container']/span[@id='nav-cart-count']")	
	private WebElement basketCount;
	@FindBy(xpath="//div[contains(text(),'Clothing')]/parent::li/following-sibling::li/child::a[text()='Clothing']")	
	private List<WebElement> mensFashionItem; 
	@FindBy(xpath="//img[@alt='Amazon Fashion']")	
	private WebElement amazonFashionImg;
	
	
	public List<WebElement> getMensFashionItem() {
		return mensFashionItem;
	}
	
	public void setMensFashionItem(List<WebElement> mensFashionItem) {
		this.mensFashionItem = mensFashionItem;
	}
	
	public WebElement getAmazonFashionImg() {
		return amazonFashionImg;
	}
	
	public void setMensFashionItem(WebElement amazonFashionImg) {
		this.amazonFashionImg = amazonFashionImg;
	}
	
	public WebElement getAllMenu() {
		return allMenu;
	}
	public WebElement getMensFashionMenu() {
		return mensFashionMenu;
	}
	public WebElement getStarFilter() {
		return starFilter;
	}
	public WebElement getPriceFilter() {
		return priceFilter;
	}
	public WebElement getPumaFilter() {
		return pumaFilter;
	}
	public WebElement getAllenSolyFilter() {
		return allenSolyFilter;
	}
	public List<WebElement> getListOfItemsInFirstPage() {
		return listOfItemsInFirstPage;
	}
	public void setAllMenu(WebElement allMenu) {
		this.allMenu = allMenu;
	}
	public void setMensFashionMenu(WebElement mensFashionMenu) {
		this.mensFashionMenu = mensFashionMenu;
	}
	public void setStarFilter(WebElement starFilter) {
		this.starFilter = starFilter;
	}
	public void setPriceFilter(WebElement priceFilter) {
		this.priceFilter = priceFilter;
	}
	public void setPumaFilter(WebElement pumaFilter) {
		this.pumaFilter = pumaFilter;
	}
	public void setAllenSolyFilter(WebElement allenSolyFilter) {
		this.allenSolyFilter = allenSolyFilter;
	}
	public void setListOfItemsInFirstPage(List<WebElement> listOfItemsInFirstPage) {
		this.listOfItemsInFirstPage = listOfItemsInFirstPage;
	}
	public void setAddToCartButton(WebElement addToCartButton) {
		this.addToCartButton = addToCartButton;
	}
	public void setBasketCount(WebElement basketCount) {
		this.basketCount = basketCount;
	}
	public WebElement getAddToCartButton() {
		return addToCartButton;
	}
	public WebElement getBasketCount() {
		return basketCount;
	}
	
	
		
	
	
}
