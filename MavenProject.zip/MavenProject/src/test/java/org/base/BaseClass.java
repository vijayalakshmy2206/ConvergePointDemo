package org.base;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.*;

import org.apache.commons.io.FileUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.DateUtil;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.github.bonigarcia.wdm.WebDriverManager;
import io.github.bonigarcia.wdm.managers.OperaDriverManager;

public class BaseClass {
	
	public static WebDriver driver;

	
	public static void browserLaunch(String chromePath) {
		try {
		String projectLocation=System.getProperty("user.dir");
		String driverPath=projectLocation+chromePath;
		System.setProperty("webdriver.chrome.driver", driverPath);
		//System.setProperty("webdriver.http.factory", "jdk-http-client");
		//WebDriverManager.chromedriver().setup();
		ChromeOptions option = new ChromeOptions();
	    option.addArguments("--remote-allow-origins=*");
		 driver=new ChromeDriver(option);
		driver.manage().window().maximize();
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public void clickByJs(WebElement element) {
		try {
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		executor.executeScript("arguments[0].click();", element);
		}catch(Exception e) {
			e.printStackTrace();
		}
	}

	public static void urlLaunch(String url) {
		try {
		driver.get(url);
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void click(WebElement e) {
		try {
		e.click();
		}catch(Exception e1) {
			e1.printStackTrace();
		}
	}
	
	public static void sendKey(WebElement e, String text) {
		e.sendKeys(text);
	}
	
	public static String getTitle() {
		String text=driver.getTitle();
		return text;
	}
	
	public static void selectByIndex(WebElement e, int index) {
		Select s=new Select(e);
		s.selectByIndex(index);
		
	}
	
	public static void selectByValue(WebElement e, String value) {
		Select s=new Select(e);
		s.selectByValue(value);
		
	}
	
	public static void selectByText(WebElement e, String text) {
		Select s=new Select(e);
		s.selectByVisibleText(text);
	}
	
	public String getData(int rowNo, int cellNo, String fileName, String sheetName) throws IOException {
		String value=null;
		File excelLoc=new File(fileName);
		FileInputStream stream=new FileInputStream(excelLoc);
		Workbook w=new XSSFWorkbook(stream);
		Sheet s=w.getSheet(sheetName);
		Row r=s.getRow(rowNo);
		Cell c=r.getCell(cellNo);
		CellType type=c.getCellType();
		String cellType=String.valueOf(type).trim();
		
	if(cellType.equalsIgnoreCase("STRING")){
		value=c.getStringCellValue();
	}
	else if(cellType.equalsIgnoreCase("NUMERIC")) {
		if(DateUtil.isCellDateFormatted(c)) {
			Date dateCellValue=c.getDateCellValue();
			SimpleDateFormat sim=new SimpleDateFormat("dd-MM-YY");
			String name=sim.format(dateCellValue);
			value=name;
		}
		else {
			double numericCellValue = c.getNumericCellValue();
			long l=(long)numericCellValue;
			String name=String.valueOf(l);
			value=name;
		}
	}
	    w.close();
		return value;
		
	}
	
	public boolean isDisplayed(WebElement e) {
		boolean flag=false;
		try {
			e.isDisplayed();
			flag=true;
		} catch (Exception e2) {
			flag=false;
			return flag;
		}
		return flag;
	}
	
	public boolean isSelected(WebElement e) {
		boolean flag=false;
		try {
			e.isSelected();
			flag=true;
		} catch (Exception e2) {
			flag=false;
			return flag;
		}
		return flag;
	}
	
	public String getText(WebElement e) {
		String text=e.getText();
		return text;
	}
	
	public void switchToWindow(int index) {
		try {
		Set<String> s=driver.getWindowHandles();
		List<String> li=new ArrayList<String>();
		li.addAll(s);
		driver.switchTo().window(li.get(index));
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public void scrollDown(WebElement e) {
		try {
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("arguments[0].scrollIntoView(true);", e);
		}catch(Exception e1) {
			e1.printStackTrace();
		}
	}
	public void wait(WebElement e) {
		/*WebDriverWait wait = new WebDriverWait(driver, 30);
		WebElement element = wait.until(
		        ExpectedConditions.visibilityOfElementLocated(e));*/
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e1) {
			e1.printStackTrace();
		}
	}
	
	public void waitTime() {
		/*WebDriverWait wait = new WebDriverWait(driver, 30);
		WebElement element = wait.until(
		        ExpectedConditions.visibilityOfElementLocated(e));*/
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e1) {
			e1.printStackTrace();
		}
	}
	
	public void moveToElement(WebElement e) {
		try {
        Actions a=new Actions(driver);
        a.moveToElement(e).build().perform();
		}catch(Exception e1) {
			e1.printStackTrace();
		}
	}
	
	public void clickAndHold(WebElement e) {
		try {
        Actions a=new Actions(driver);
        a.moveToElement(e).clickAndHold(e).build().perform();
		}catch(Exception e1) {
			e1.printStackTrace();
		}
	}
	
	public void browserQuit() {
		driver.quit();
	}
	
	public void takeScreenShot(String fileWithPath) {
		try {
		TakesScreenshot scrShot =((TakesScreenshot)driver);
		File SrcFile=scrShot.getScreenshotAs(OutputType.FILE);
		File DestFile=new File(fileWithPath);
		FileUtils.copyFile(SrcFile, DestFile);
		}catch(Exception e1) {
			e1.printStackTrace();
		}
	}
}
