package com.stepdefinitions;

import java.util.List;

import org.base.BaseClass;
import org.junit.Assert;
import org.openqa.selenium.WebElement;
import org.pageobject.HomePage;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;


public class HomePageTest extends BaseClass {
	
	public static HomePage search;
	String basKetCount;
	
	
	@Given("Navigate to Amazon.in homepage.")
	public void navigate_to_Amazon_in_homepage() {
		urlLaunch("https://www.amazon.in/");
		search=new HomePage();
		Assert.assertTrue(isDisplayed(search.getAllMenu()));
	}

	@When("Click on Fashion and Click on Mens")
	public void click_on_Fashion_and_Click_on_Mens() {
	   click(search.getAllMenu());
	   wait(search.getMensFashionMenu());
	   click(search.getMensFashionMenu());
	   wait(search.getMensFashionItem().get(0));
	   moveToElement(search.getMensFashionItem().get(0));
	   clickByJs(search.getMensFashionItem().get(0));
	   Assert.assertTrue(isDisplayed(search.getAmazonFashionImg()));
	}

	@When("Filter by Average customer review of {int} stars and Up")
	public void filter_by_Average_customer_review_of_stars_and_Up(Integer int1) {
	   Assert.assertTrue(isDisplayed(search.getStarFilter()));
	   scrollDown(search.getStarFilter());
	   clickByJs(search.getStarFilter()); 
	}

	@When("Filter by price")
	public void filter_by_price() {
		Assert.assertTrue(isDisplayed(search.getPriceFilter()));
		scrollDown(search.getPriceFilter());
		clickByJs(search.getPriceFilter()); 
	}

	@When("Select Puma and Allen Solly in Brands")
	public void select_Puma_and_Allen_Solly_in_Brands() {
		basKetCount =getText(search.getBasketCount());
		Assert.assertTrue(isDisplayed(search.getAllenSolyFilter()));
		wait(search.getAllenSolyFilter());
		scrollDown(search.getAllenSolyFilter());
		//clickByJs(search.getPumaFilter()); 
		clickByJs(search.getAllenSolyFilter()); 
	}

	@When("Count the number of results in the first page and log it to console.")
	public void count_the_number_of_results_in_the_first_page_and_log_it_to_console(){
		waitTime();
	    List<WebElement> items=search.getListOfItemsInFirstPage();
	    System.out.println("<=======Number of results displayed in first page: "+items.size()+" ========>");
	    Assert.assertTrue(items.size()>0);
	    //String projectLocation=System.getProperty("user.dir");
	    takeScreenShot("C:\\Users\\Admin\\Downloads\\MavenProject\\MavenProject\\src\\test\\resources\\Reports\\AmazonStep6.png");
	}

	@When("Click second product and add it to Cart.")
	public void click_second_product_and_add_it_to_Cart() {
	   clickByJs(search.getListOfItemsInFirstPage().get(1));
	   switchToWindow(1);
	   Assert.assertTrue(isDisplayed(search.getAddToCartButton()));
	   scrollDown(search.getAddToCartButton());
	   clickByJs(search.getAddToCartButton());  
	}

	
	@Then("Validate Number on the Cart is increased by one")
	public void validate_Number_on_the_Cart_is_increased_by_one() {
	   String expected=getText(search.getBasketCount());
	   Assert.assertTrue(expected.equals("1"));
	}


}
