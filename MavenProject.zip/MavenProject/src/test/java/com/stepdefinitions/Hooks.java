package com.stepdefinitions;

import org.base.BaseClass;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import io.cucumber.java.After;
import io.cucumber.java.Before;

public class Hooks extends BaseClass{
	
	@Before
	public void launchBrowser() {
		browserLaunch("\\drivers\\chromedriver.exe");
	}

	@After(order=0)
	public void quitBrowser() {
		browserQuit();
	}
	
	@After(order = 1)
	public void takeScraenshotOnFailure(io.cucumber.java.Scenario scenario) {
	if (scenario.isFailed()) {
	/*TakesScreenshot ts = (TakesScreenshot) driver;
	byte[] src = ts.getScreenshotAs(OutputType.BYTES);
	scenario.embed(src, "FailedScreenshot");*/
	takeScreenShot("C:\\Users\\Admin\\Downloads\\MavenProject\\MavenProject\\src\\test\\resources\\Reports\\Failed.png");
	}
	}
}
