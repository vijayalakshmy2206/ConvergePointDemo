package com.testRunner;

import org.junit.runner.RunWith;


import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;

@RunWith(Cucumber.class)
@CucumberOptions(features= {"src/test/resources"}, glue= {"com.stepdefinitions"},plugin= {"html:src\\test\\resources\\Reports\\Amazon"})

public class TestRunner{
	

}
